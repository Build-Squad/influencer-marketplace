from solders.pubkey import Pubkey

PROGRAM_ID = Pubkey.from_string("GxojWLjFSxSaCBBDzu6ynZ8QTmwUDtN65TMEtNF6P8ig")
