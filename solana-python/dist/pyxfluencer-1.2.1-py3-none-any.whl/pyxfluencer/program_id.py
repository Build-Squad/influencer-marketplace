from solders.pubkey import Pubkey

PROGRAM_ID = Pubkey.from_string("DmYaabL1PhacWWsRwyZpBqBP9n7tVq7115zG2tznYLb9")
