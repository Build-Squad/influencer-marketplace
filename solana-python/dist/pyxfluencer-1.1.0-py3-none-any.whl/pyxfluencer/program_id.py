from solders.pubkey import Pubkey

PROGRAM_ID = Pubkey.from_string("6mTwD92ynqwDZxjg2ydhAjeX5w7bcsfM7jQUDeHpGM9G")
