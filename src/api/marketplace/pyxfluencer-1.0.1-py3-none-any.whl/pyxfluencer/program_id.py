from solders.pubkey import Pubkey

PROGRAM_ID = Pubkey.from_string("7zNs7f6rJyhvu9k4DZwqeqgBa27GqX12mVeQAS528xEq")
